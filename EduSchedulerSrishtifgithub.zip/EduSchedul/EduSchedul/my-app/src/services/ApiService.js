// API service for EduScheduler
const API_BASE_URL = "http://localhost:3001/api";

class ApiService {
  // Authentication
  static async login(credentials) {
    try {
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
      });
      return await response.json();
    } catch (error) {
      console.error("Login API error:", error);
      throw error;
    }
  }

  static async register(userData) {
    try {
      const response = await fetch(`${API_BASE_URL}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      });
      return await response.json();
    } catch (error) {
      console.error("Register API error:", error);
      throw error;
    }
  }

  // Data fetching
  static async fetchData() {
    try {
      const response = await fetch(`${API_BASE_URL}/data`);
      return await response.json();
    } catch (error) {
      console.error("Fetch data API error:", error);
      throw error;
    }
  }

  // Subjects
  static async addSubject(subject) {
    try {
      const response = await fetch(`${API_BASE_URL}/subjects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(subject),
      });
      return await response.json();
    } catch (error) {
      console.error("Add subject API error:", error);
      throw error;
    }
  }

  // Faculty
  static async addFaculty(faculty) {
    try {
      const response = await fetch(`${API_BASE_URL}/faculty`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(faculty),
      });
      return await response.json();
    } catch (error) {
      console.error("Add faculty API error:", error);
      throw error;
    }
  }

  // Classrooms
  static async addClassroom(classroom) {
    try {
      const response = await fetch(`${API_BASE_URL}/classrooms`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(classroom),
      });
      return await response.json();
    } catch (error) {
      console.error("Add classroom API error:", error);
      throw error;
    }
  }

  // Timetables
  static async addTimetable(timetable) {
    try {
      const response = await fetch(`${API_BASE_URL}/timetables`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(timetable),
      });
      return await response.json();
    } catch (error) {
      console.error("Add timetable API error:", error);
      throw error;
    }
  }

  static async updateTimetable(id, status) {
    try {
      const response = await fetch(`${API_BASE_URL}/timetables/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      return await response.json();
    } catch (error) {
      console.error("Update timetable API error:", error);
      throw error;
    }
  }
}

export default ApiService;