const DashboardPage = ({ user, subjects = [], faculty = [], classrooms = [], onTabChange }) => {
  console.log('Dashboard props:', { user, subjects: subjects?.length, faculty: faculty?.length, classrooms: classrooms?.length });
  
  const deptCount = subjects.length > 0 ? [...new Set(subjects.map((s) => s.subjectDepartment))]
    .length : 0;

  return (
    <div className="dashboard-container">
      <div className="logged-in-container">
        <div className="profile-card">
          <h3>
            Welcome,{" "}
            <span id="userNameDisplay">{user?.username || "User"}!</span>
          </h3>
          <p>
            You are logged in as <strong>{user?.role || "Guest"}</strong>
          </p>
        </div>
        <div className="dashboard-quick-actions">
          <button 
            className="btn btn-primary" 
            onClick={() => onTabChange && onTabChange('optimize')}
          >
            Generate New Timetable
          </button>
          <button 
            className="btn btn-info" 
            onClick={() => onTabChange && onTabChange('review')}
          >
            View Pending Approvals
          </button>
        </div>
        <div className="dashboard-stats">
          <div className="stat-card">
            <div className="stat-value">{deptCount}</div>
            <div>Active Departments</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{faculty.length}</div>
            <div>Faculty Members</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">3,456</div>
            <div>Students</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{classrooms.length}</div>
            <div>Classrooms</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;