import { useState } from "react";

const LoginPage = ({ onLogin, onShowRegister }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:3001/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, role }),
      });
      if (response.ok) {
        const data = await response.json();
        onLogin(data.user);
      } else {
        alert("Login failed. Please check your credentials.");
      }
    } catch (error) {
      console.error("Login error:", error);
      alert("An error occurred during login.");
    }
  };

  return (
    <div id="login" className="tab-pane active">
      <div className="login-form">
        <h2 style={{ marginBottom: "30px", color: "#667eea" }}>
          Authorized Access
        </h2>
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              required
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
          </div>
          <div className="form-group">
            <label>Role</label>
            <select
              className="form-control"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              required
            >
              <option value="">Select Role</option>
              <option value="admin">Administrator</option>
              <option value="hod">Head of Department</option>
              <option value="faculty">Faculty Coordinator</option>
              <option value="registrar">Registrar</option>
            </select>
          </div>
          <button type="submit" className="btn btn-primary">
            Login
          </button>
        </form>
        <div style={{ marginTop: "15px", textAlign: "center" }}>
          <small style={{ color: "#666" }}>Don't have an account?</small>
          <br />
          <button
            className="btn btn-success"
            style={{ marginTop: "10px" }}
            onClick={onShowRegister}
          >
            Register
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;