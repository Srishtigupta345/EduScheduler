// Application constants
export const API_ENDPOINTS = {
  BASE_URL: "http://localhost:3001/api",
  LOGIN: "/login",
  REGISTER: "/register",
  DATA: "/data",
  SUBJECTS: "/subjects",
  FACULTY: "/faculty",
  CLASSROOMS: "/classrooms",
  TIMETABLES: "/timetables",
};

export const USER_ROLES = {
  ADMIN: "admin",
  HOD: "hod",
  FACULTY: "faculty",
  REGISTRAR: "registrar",
};

export const TAB_NAMES = {
  LOGIN: "login",
  REGISTER: "register",
  DASHBOARD: "dashboard",
  INPUT: "input",
  OPTIMIZE: "optimize",
  REVIEW: "review",
};

export const NOTIFICATION_TYPES = {
  SUCCESS: "success",
  ERROR: "error",
  INFO: "info",
  WARNING: "warning",
};

export const TIMETABLE_STATUS = {
  PENDING: "pending",
  APPROVED: "approved",
  REJECTED: "rejected",
};

export const DEFAULT_CREDENTIALS = {
  DEMO_USERNAME: "admin",
  DEMO_PASSWORD: "admin",
  DEMO_ROLE: "admin",
};