﻿import { useEffect, useState, useCallback } from "react";
import DashboardPage from "./pages/DashboardPage";
import LoginPage from "./pages/LoginPage";
import RegistrationPage from "./pages/RegistrationPage";
import DataInput from "./components/DataInput";
import Notifications from "./components/Notifications";
import Review from "./components/Review";
import TimetableGenerator from "./components/TimetableGenerator";
import ApiService from "./services/ApiService";
import { TAB_NAMES, NOTIFICATION_TYPES } from "./constants";

const App = () => {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState(TAB_NAMES.LOGIN);
  const [notifications, setNotifications] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [classrooms, setClassrooms] = useState([]);
  const [timetables, setTimetables] = useState([]);
  const [theme, setTheme] = useState("light");

  const addNotification = useCallback((type, title, message) => {
    const newNotification = {
      id: Date.now(),
      type,
      title,
      message,
      timestamp: new Date(),
      read: false,
    };
    setNotifications((prev) => [newNotification, ...prev]);
  }, []);

  const fetchData = useCallback(async () => {
    console.log('Fetching data from API...');
    try {
      const data = await ApiService.fetchData();
      console.log('API Data received:', { 
        subjects: data.subjects?.length, 
        faculty: data.faculty?.length, 
        classrooms: data.classrooms?.length 
      });
      setSubjects(data.subjects);
      setFaculty(data.faculty);
      setClassrooms(data.classrooms);
      setTimetables(data.timetables);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      addNotification(
        NOTIFICATION_TYPES.ERROR,
        "Data Fetch Failed",
        "Unable to load application data."
      );
    }
  }, [addNotification]);

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "light";
    setTheme(savedTheme);
    document.body.classList.toggle("dark-mode", savedTheme === "dark");
    fetchData();
    
    // Add welcome notification
    setTimeout(() => {
      addNotification(
        NOTIFICATION_TYPES.INFO,
        "Welcome to EduSchedul",
        "Start by adding subjects, faculty, and classrooms to generate timetables."
      );
    }, 1000);
  }, [fetchData, addNotification]);

  const handleLogin = (loggedInUser) => {
    setUser(loggedInUser);
    setActiveTab(TAB_NAMES.DASHBOARD);
    fetchData();
    addNotification(
      NOTIFICATION_TYPES.SUCCESS,
      "Login Successful",
      `Welcome, ${loggedInUser.username}!`
    );
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab(TAB_NAMES.LOGIN);
    addNotification(NOTIFICATION_TYPES.INFO, "Logged Out", "You have been logged out.");
  };

  const handleShowRegister = () => {
    setActiveTab(TAB_NAMES.REGISTER);
  };

  const handleBackToLogin = () => {
    setActiveTab(TAB_NAMES.LOGIN);
  };

  const handleRegister = (newUser) => {
    addNotification(
      NOTIFICATION_TYPES.SUCCESS,
      "Registration Successful",
      `Account created for ${newUser.username}! Please login.`
    );
    setActiveTab(TAB_NAMES.LOGIN);
  };

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    document.body.classList.toggle("dark-mode");
    localStorage.setItem("theme", newTheme);
  };

  const addSubject = async (newSubject) => {
    try {
      const addedSubject = await ApiService.addSubject(newSubject);
      setSubjects([...subjects, addedSubject]);
      addNotification(
        NOTIFICATION_TYPES.SUCCESS,
        "Subject Added",
        `Subject "${addedSubject.subjectName}" has been added.`
      );
    } catch (error) {
      addNotification(NOTIFICATION_TYPES.ERROR, "Error", "Failed to add subject.");
    }
  };

  const addFaculty = async (newFaculty) => {
    try {
      const addedFaculty = await ApiService.addFaculty(newFaculty);
      setFaculty([...faculty, addedFaculty]);
      addNotification(
        NOTIFICATION_TYPES.SUCCESS,
        "Faculty Added",
        `Faculty "${addedFaculty.facultyName}" has been added.`
      );
    } catch (error) {
      addNotification(NOTIFICATION_TYPES.ERROR, "Error", "Failed to add faculty.");
    }
  };

  const addClassroom = async (newClassroom) => {
    try {
      const addedClassroom = await ApiService.addClassroom(newClassroom);
      setClassrooms([...classrooms, addedClassroom]);
      addNotification(
        NOTIFICATION_TYPES.SUCCESS,
        "Classroom Added",
        `Classroom "${addedClassroom.roomNumber}" has been added.`
      );
    } catch (error) {
      addNotification(NOTIFICATION_TYPES.ERROR, "Error", "Failed to add classroom.");
    }
  };

  const generateTimetable = async (timetableData) => {
    try {
      const newTimetable = await ApiService.addTimetable(timetableData);
      setTimetables([...timetables, newTimetable]);
      addNotification(
        NOTIFICATION_TYPES.SUCCESS,
        "Timetable Generated",
        "New timetable has been generated and is pending approval."
      );
      // Automatically switch to review tab
      setActiveTab(TAB_NAMES.REVIEW);
    } catch (error) {
      addNotification(NOTIFICATION_TYPES.ERROR, "Error", "Failed to generate timetable.");
    }
  };

  const handleTimetableApproval = async (id, status) => {
    try {
      const updatedTimetable = await ApiService.updateTimetable(id, status);
      setTimetables(
        timetables.map((t) => (t.id === id ? updatedTimetable : t))
      );
      addNotification(
        NOTIFICATION_TYPES.SUCCESS,
        "Timetable Updated",
        `Timetable has been ${status}.`
      );
    } catch (error) {
      addNotification(NOTIFICATION_TYPES.ERROR, "Error", "Failed to update timetable.");
    }
  };

  const handleCloseReview = () => {
    setActiveTab(TAB_NAMES.OPTIMIZE);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case TAB_NAMES.LOGIN:
        return <LoginPage onLogin={handleLogin} onShowRegister={handleShowRegister} />;
      case TAB_NAMES.REGISTER:
        return <RegistrationPage onRegister={handleRegister} onBackToLogin={handleBackToLogin} />;
      case TAB_NAMES.DASHBOARD:
        return (
          <DashboardPage
            subjects={subjects}
            faculty={faculty}
            classrooms={classrooms}
            user={user}
            onTabChange={setActiveTab}
          />
        );
      case TAB_NAMES.INPUT:
        return (
          <DataInput
            subjects={subjects}
            faculty={faculty}
            classrooms={classrooms}
            onAddSubject={addSubject}
            onAddFaculty={addFaculty}
            onAddClassroom={addClassroom}
          />
        );
      case TAB_NAMES.OPTIMIZE:
        return (
          <TimetableGenerator
            subjects={subjects}
            faculty={faculty}
            classrooms={classrooms}
            onGenerate={generateTimetable}
          />
        );
      case TAB_NAMES.REVIEW:
        return <Review timetables={timetables} onApprove={handleTimetableApproval} onClose={handleCloseReview} />;
      default:
        return <LoginPage onLogin={handleLogin} onShowRegister={handleShowRegister} />;
    }
  };

  return (
    <div className="container">
      <div className="header">
        <h1>EduScheduler Pro</h1>
        <p>Intelligent Timetable Optimization for Higher Education</p>
        {user && (
          <button className="btn btn-danger logout-btn" onClick={handleLogout}>
            Logout
          </button>
        )}
        <div className="top-right-actions">
          <button id="theme-toggle" onClick={toggleTheme}>
            {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </button>
          <Notifications
            notifications={notifications}
            setNotifications={setNotifications}
          />
        </div>
      </div>

      <div className="main-content">
        <div className="nav-tabs">
          <button
            className={`nav-tab ${activeTab === TAB_NAMES.LOGIN ? "active" : ""}`}
            onClick={() => setActiveTab(TAB_NAMES.LOGIN)}
          >
            Login
          </button>
          {!user && (
            <button
              className={`nav-tab ${activeTab === TAB_NAMES.REGISTER ? "active" : ""}`}
              onClick={() => setActiveTab(TAB_NAMES.REGISTER)}
            >
              Register
            </button>
          )}
          {user && (
            <>
              <button
                className={`nav-tab ${
                  activeTab === TAB_NAMES.DASHBOARD ? "active" : ""
                }`}
                onClick={() => setActiveTab(TAB_NAMES.DASHBOARD)}
              >
                Dashboard
              </button>
              <button
                className={`nav-tab ${activeTab === TAB_NAMES.INPUT ? "active" : ""}`}
                onClick={() => setActiveTab(TAB_NAMES.INPUT)}
              >
                Data Input
              </button>
              <button
                className={`nav-tab ${
                  activeTab === TAB_NAMES.OPTIMIZE ? "active" : ""
                }`}
                onClick={() => setActiveTab(TAB_NAMES.OPTIMIZE)}
              >
                Generate Timetable
              </button>
              <button
                className={`nav-tab ${activeTab === TAB_NAMES.REVIEW ? "active" : ""}`}
                onClick={() => setActiveTab(TAB_NAMES.REVIEW)}
              >
                Review & Approval
              </button>
            </>
          )}
        </div>

        <div className="tab-content">{renderTabContent()}</div>
      </div>
    </div>
  );
};

export default App;
