import { useState } from "react";

const DataInput = ({
  onAddSubject,
  onAddFaculty,
  onAddClassroom,
  subjects,
  faculty,
  classrooms,
}) => {
  const [subjectName, setSubjectName] = useState("");
  const [classesPerWeek, setClassesPerWeek] = useState("");
  const [subjectDepartment, setSubjectDepartment] = useState("CSE");
  const [subjectSemester, setSubjectSemester] = useState("1");
  const [subjectPriority, setSubjectPriority] = useState("Medium");

  const [facultyName, setFacultyName] = useState("");
  const [specialization, setSpecialization] = useState("");

  const [classroomName, setClassroomName] = useState("");
  const [classroomType, setClassroomType] = useState("Lecture Hall");

  const handleAddSubject = () => {
    if (subjectName && classesPerWeek) {
      onAddSubject({
        subjectName,
        classesPerWeek: parseInt(classesPerWeek),
        subjectDepartment,
        subjectSemester: parseInt(subjectSemester),
        priority: subjectPriority,
      });
      setSubjectName("");
      setClassesPerWeek("");
      setSubjectPriority("Medium");
    }
  };

  const handleAddFaculty = () => {
    if (facultyName) {
      onAddFaculty({ facultyName, specialization });
      setFacultyName("");
      setSpecialization("");
    }
  };

  const handleAddClassroom = () => {
    if (classroomName) {
      onAddClassroom({ classroomName, classroomType });
      setClassroomName("");
    }
  };

  return (
    <div id="input" className="tab-pane active">
      <h2 style={{ marginBottom: "30px", color: "#667eea" }}>
        Data Input & Configuration
      </h2>
      <div className="input-search-container">
        <input
          type="text"
          className="form-control"
          placeholder="Search for subjects, faculty, or classrooms..."
        />
        <span className="search-icon">🔍</span>
      </div>
      <div className="grid">
        <div className="card">
          <h3>Subject Configuration</h3>
          <div className="form-group">
            <label>Subject Name</label>
            <input
              type="text"
              className="form-control"
              value={subjectName}
              onChange={(e) => setSubjectName(e.target.value)}
              placeholder="e.g., Data Structures"
            />
          </div>
          <div className="form-group">
            <label>Classes per Week</label>
            <input
              type="number"
              className="form-control"
              value={classesPerWeek}
              onChange={(e) => setClassesPerWeek(e.target.value)}
              placeholder="e.g., 4"
            />
          </div>
          <div className="form-group">
            <label>Department</label>
            <select
              className="form-control"
              value={subjectDepartment}
              onChange={(e) => setSubjectDepartment(e.target.value)}
            >
              <option value="CSE">CSE</option>
              <option value="ECE">ECE</option>
              <option value="ME">ME</option>
              <option value="CE">CE</option>
            </select>
          </div>
          <div className="form-group">
            <label>Semester</label>
            <select
              className="form-control"
              value={subjectSemester}
              onChange={(e) => setSubjectSemester(e.target.value)}
            >
              {[...Array(8)].map((_, i) => (
                <option key={i + 1} value={i + 1}>
                  {i + 1}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Priority</label>
            <select
              className="form-control"
              value={subjectPriority}
              onChange={(e) => setSubjectPriority(e.target.value)}
            >
              <option value="High">High (Morning Slots)</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
          <button className="btn btn-success" onClick={handleAddSubject}>
            Add Subject
          </button>
        </div>
        <div className="card">
          <h3>Faculty Configuration</h3>
          <div className="form-group">
            <label>Faculty Name</label>
            <input
              type="text"
              className="form-control"
              value={facultyName}
              onChange={(e) => setFacultyName(e.target.value)}
              placeholder="e.g., Dr. John Smith"
            />
          </div>
          <div className="form-group">
            <label>Specialization</label>
            <input
              type="text"
              className="form-control"
              value={specialization}
              onChange={(e) => setSpecialization(e.target.value)}
              placeholder="e.g., Machine Learning"
            />
          </div>
          <button className="btn btn-success" onClick={handleAddFaculty}>
            Add Faculty
          </button>
        </div>
        <div className="card">
          <h3>Classroom Configuration</h3>
          <div className="form-group">
            <label>Classroom Name</label>
            <input
              type="text"
              className="form-control"
              value={classroomName}
              onChange={(e) => setClassroomName(e.target.value)}
              placeholder="e.g., C-101"
            />
          </div>
          <div className="form-group">
            <label>Classroom Type</label>
            <select
              className="form-control"
              value={classroomType}
              onChange={(e) => setClassroomType(e.target.value)}
            >
              <option value="Lecture Hall">Lecture Hall</option>
              <option value="Lab">Lab</option>
            </select>
          </div>
          <button className="btn btn-success" onClick={handleAddClassroom}>
            Add Classroom
          </button>
        </div>
        <div className="card">
          <h3>Faculty Attendance</h3>
          <div className="form-group">
            <label>Select Faculty</label>
            <select className="form-control">
              <option value="">Select a Faculty...</option>
              {faculty.map((f, i) => (
                <option key={i}>{f.facultyName}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className="grid">
        <div className="card">
          <h3>Added Subjects</h3>
          <div className="list-container">
            <ul className="list-unstyled">
              {subjects.map((s, i) => (
                <li key={i}>
                  {s.subjectName} ({s.subjectDepartment})
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="card">
          <h3>Added Faculty</h3>
          <div className="list-container">
            <ul className="list-unstyled">
              {faculty.map((f, i) => (
                <li key={i}>
                  {f.facultyName} ({f.specialization})
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="card">
          <h3>Added Classrooms</h3>
          <div className="list-container">
            <ul className="list-unstyled">
              {classrooms.map((c, i) => (
                <li key={i}>
                  {c.classroomName} ({c.classroomType})
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataInput;
