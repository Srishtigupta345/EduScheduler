import { useState, useEffect, useRef } from "react";

const Notifications = ({ notifications, setNotifications }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const clearAll = () => {
    setNotifications([]);
  };

  const markAsRead = (id) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const formatTime = (timestamp) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now - new Date(timestamp)) / (1000 * 60));
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  return (
    <div className="notification-bell" onClick={toggleDropdown} ref={dropdownRef}>
      <div className="bell-icon">🔔</div>
      <div
        className="notification-badge"
        style={{ display: unreadCount > 0 ? "flex" : "none" }}
      >
        {unreadCount}
      </div>

      <div
        className={`notification-dropdown ${dropdownOpen ? "show" : ""}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="notification-header">
          <h4>Notifications</h4>
          <span className="clear-all-btn" onClick={clearAll}>
            Clear All
          </span>
        </div>
        <div id="notificationList">
          {notifications.length === 0 ? (
            <div
              style={{ padding: "20px", textAlign: "center", color: "#999" }}
            >
              No notifications yet
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                className={`notification-item ${notif.read ? "" : "unread"}`}
                onClick={() => markAsRead(notif.id)}
              >
                <div className={`notification-type ${notif.type}`}>
                  {notif.type.charAt(0).toUpperCase() + notif.type.slice(1)}
                </div>
                <div className="notification-title">{notif.title}</div>
                <div className="notification-message">{notif.message}</div>
                <div className="notification-time">
                  {formatTime(notif.timestamp)}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Notifications;
