import { useState } from "react";

const TimetableGenerator = ({ subjects, faculty, classrooms, onGenerate }) => {
  const [department, setDepartment] = useState("CSE");
  const [semester, setSemester] = useState("5");
  const [periodCount, setPeriodCount] = useState(6);
  const [maxFacultyClasses, setMaxFacultyClasses] = useState(3);
  const [avoidBackToBack, setAvoidBackToBack] = useState(true);
  const [addRecess, setAddRecess] = useState(true);
  const [weeklyHoliday, setWeeklyHoliday] = useState("None");
  const [timetable, setTimetable] = useState(null);

  const generateTimetable = () => {
    // This is a simplified generation logic for demonstration with priority support
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    if (weeklyHoliday !== "None") {
      const holidayIndex = days.indexOf(weeklyHoliday);
      if (holidayIndex > -1) {
        days.splice(holidayIndex, 1);
      }
    }

    const periods = Array.from(
      { length: periodCount },
      (_, i) => `Period ${i + 1}`
    );
    const generatedTimetable = {};
    const subjectPool = subjects.filter(
      (s) =>
        s.subjectDepartment === department &&
        s.subjectSemester.toString() === semester
    );

    // Sort subjects by priority (High > Medium > Low)
    const priorityOrder = { "High": 3, "Medium": 2, "Low": 1 };
    const sortedSubjects = subjectPool.sort((a, b) => {
      const priorityA = priorityOrder[a.priority] || 2; // Default to Medium if no priority
      const priorityB = priorityOrder[b.priority] || 2;
      return priorityB - priorityA; // Sort in descending order (High first)
    });

    // Get all available faculty (not filtering by specialization to avoid empty faculty pool)
    const facultyPool = faculty.length > 0 ? faculty : [];
    const classroomPool = classrooms;

    // Check if we have required data
    if (sortedSubjects.length === 0) {
      alert(`No subjects found for ${department} department, semester ${semester}`);
      return;
    }
    
    if (facultyPool.length === 0) {
      alert("No faculty available. Please add faculty first.");
      return;
    }
    
    if (classroomPool.length === 0) {
      alert("No classrooms available. Please add classrooms first.");
      return;
    }

    console.log("Debug - Subjects found:", sortedSubjects);
    console.log("Debug - Faculty pool:", facultyPool);
    console.log("Debug - Classroom pool:", classroomPool);

    const facultyLoads = {};
    facultyPool.forEach((f) => (facultyLoads[f.facultyName] = 0));

    for (const day of days) {
      generatedTimetable[day] = {};
      for (const period of periods) {
        generatedTimetable[day][period] = "Free";
      }
    }

    let assignedFaculty = {};

    // Create schedule entries for each subject based on classes per week, prioritized
    let scheduleEntries = [];
    sortedSubjects.forEach(subject => {
      for (let i = 0; i < subject.classesPerWeek; i++) {
        scheduleEntries.push({
          ...subject,
          entryId: `${subject.id}_${i}`
        });
      }
    });

    // Sort schedule entries by priority to ensure high priority subjects get better time slots
    scheduleEntries = scheduleEntries.sort((a, b) => {
      const priorityA = priorityOrder[a.priority] || 2;
      const priorityB = priorityOrder[b.priority] || 2;
      return priorityB - priorityA;
    });

    let entryIndex = 0;

    console.log("Debug - Schedule entries:", scheduleEntries);
    console.log("Debug - Max faculty classes:", maxFacultyClasses);

    // Assign subjects with priority preference for earlier periods
    for (const day of days) {
      for (const period of periods) {
        if (entryIndex >= scheduleEntries.length) break;
        
        const subject = scheduleEntries[entryIndex];
        console.log(`Debug - Assigning ${subject.subjectName} to ${day} ${period}`);
        
        const availableFaculty = facultyPool.filter(
          (f) =>
            !assignedFaculty[subject.subjectName] ||
            assignedFaculty[subject.subjectName] === f.facultyName
        );
        const assignedF =
          assignedFaculty[subject.subjectName] ||
          availableFaculty[0]?.facultyName;

        console.log(`Debug - Available faculty:`, availableFaculty);
        console.log(`Debug - Assigned faculty:`, assignedF);
        console.log(`Debug - Faculty loads:`, facultyLoads);

        if (assignedF && facultyLoads[assignedF] < maxFacultyClasses) {
          assignedFaculty[subject.subjectName] = assignedF;
          generatedTimetable[day][period] = {
            subject: subject.subjectName,
            faculty: assignedF,
            classroom:
              classroomPool[
                Math.floor(Math.random() * classroomPool.length)
              ].classroomName,
            priority: subject.priority || "Medium"
          };
          facultyLoads[assignedF]++;
          entryIndex++;
          console.log(`Debug - Successfully assigned ${subject.subjectName}`);
        } else {
          console.log(`Debug - Failed to assign ${subject.subjectName} - no faculty or max load reached`);
        }
      }
      if (entryIndex >= scheduleEntries.length) break;
    }

    setTimetable(generatedTimetable);
    onGenerate({
      department,
      semester,
      timetable: generatedTimetable,
      metadata: {
        periodCount,
        maxFacultyClasses,
        avoidBackToBack,
        addRecess,
        weeklyHoliday,
      },
    });
  };

  const renderTimetable = () => {
    if (!timetable)
      return (
        <div className="alert alert-info">No timetable generated yet.</div>
      );

    const days = Object.keys(timetable);
    const periods = timetable[days[0]] ? Object.keys(timetable[days[0]]) : [];

    return (
      <table className="timetable-table">
        <thead>
          <tr>
            <th>Time / Day</th>
            {days.map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {periods.map((period) => (
            <tr key={period}>
              <td>{period}</td>
              {days.map((day) => {
                const cell = timetable[day][period];
                return (
                  <td key={day + period} className={cell !== "Free" && cell.priority ? `priority-${cell.priority.toLowerCase()}` : ""}>
                    {cell !== "Free"
                      ? (
                          <div className="schedule-cell">
                            <div className="subject-name">{cell.subject}</div>
                            <div className="faculty-name">({cell.faculty})</div>
                            {cell.priority && (
                              <div className="priority-badge">
                                <span className={`priority-${cell.priority.toLowerCase()}`}>
                                  {cell.priority} Priority
                                </span>
                              </div>
                            )}
                          </div>
                        )
                      : "Free"}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div id="optimize" className="tab-pane active">
      <h2 style={{ marginBottom: "30px", color: "#667eea" }}>
        Timetable Generation
      </h2>
      <div className="card">
        <h3>Configuration Options</h3>
        <div className="grid">
          <div className="form-group">
            <label>Select Department</label>
            <select
              className="form-control"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
            >
              <option value="CSE">Computer Science & Engineering</option>
              <option value="ECE">
                Electronics & Communication Engineering
              </option>
              <option value="ME">Mechanical Engineering</option>
              <option value="CE">Civil Engineering</option>
            </select>
          </div>
          <div className="form-group">
            <label>Select Semester</label>
            <select
              className="form-control"
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
            >
              {[...Array(8)].map((_, i) => (
                <option key={i + 1} value={i + 1}>
                  Semester {i + 1}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Periods Per Day</label>
            <input
              type="number"
              className="form-control"
              value={periodCount}
              onChange={(e) => setPeriodCount(e.target.value)}
              min="1"
              max="10"
            />
          </div>
          <div className="form-group">
            <label>Max Classes Per Day (Faculty)</label>
            <input
              type="number"
              className="form-control"
              value={maxFacultyClasses}
              onChange={(e) => setMaxFacultyClasses(e.target.value)}
              min="1"
              max="5"
            />
          </div>
        </div>
      </div>
      <button
        className="btn btn-primary"
        style={{ width: "100%", marginTop: "20px" }}
        onClick={generateTimetable}
      >
        Generate Optimized Timetable
      </button>
      <div id="timetable-display" className="timetable-container">
        <h3>Generated Timetable</h3>
        <div id="timetable-table-container">{renderTimetable()}</div>
      </div>
    </div>
  );
};

export default TimetableGenerator;
