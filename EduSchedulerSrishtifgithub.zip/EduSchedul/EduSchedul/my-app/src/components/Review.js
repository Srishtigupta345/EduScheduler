import { useState } from "react";

const Review = ({ timetables, onApprove, onClose }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredTimetables = timetables.filter(
    (t) =>
      t.status === "pending" &&
      (t.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.semester.toString().includes(searchTerm))
  );

  const handleApproval = (id, status) => {
    onApprove(id, status);
  };

  const renderTimetable = (timetableData) => {
    if (!timetableData) return null;
    const days = Object.keys(timetableData);
    if (days.length === 0) return null;
    const periods = Object.keys(timetableData[days[0]]);

    return (
      <table className="timetable-table">
        <thead>
          <tr>
            <th>Time / Day</th>
            {days.map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {periods.map((period) => (
            <tr key={period}>
              <td>{period}</td>
              {days.map((day) => {
                const cell = timetableData[day][period];
                return (
                  <td key={day + period}>
                    {cell !== "Free"
                      ? `${cell.subject} (${cell.faculty})`
                      : "Free"}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div id="review" className="tab-pane active">
      <div className="review-header">
        <h2 style={{ marginBottom: "30px", color: "#667eea" }}>
          Review & Approval Workflow
        </h2>
        {onClose && (
          <button 
            className="close-btn" 
            onClick={onClose}
            title="Close Review"
          >
            ×
          </button>
        )}
      </div>
      <div className="input-search-container">
        <input
          type="text"
          className="form-control"
          placeholder="Search approvals by name or department..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <span className="search-icon">🔍</span>
      </div>
      <div className="card">
        <h3>Pending Approvals</h3>
        <div id="approvals-list-container">
          {filteredTimetables.length === 0 ? (
            <div className="alert alert-info">
              No pending approvals at the moment.
            </div>
          ) : (
            filteredTimetables.map((tt) => (
              <div key={tt.id} className="approval-item" data-id={tt.id}>
                <h4>
                  Timetable for {tt.department}, Semester {tt.semester}
                </h4>
                <div className="review-buttons">
                  <button
                    className="btn btn-success"
                    onClick={() => handleApproval(tt.id, "approved")}
                  >
                    Approve
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => handleApproval(tt.id, "rejected")}
                  >
                    Reject
                  </button>
                </div>
                {renderTimetable(tt.timetable)}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Review;
