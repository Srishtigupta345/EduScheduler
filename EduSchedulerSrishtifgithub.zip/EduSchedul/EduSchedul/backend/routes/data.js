const express = require("express");
const DataController = require("../controllers/DataController");

const router = express.Router();

// Data routes
router.get("/data", DataController.getData);
router.post("/subjects", DataController.addSubject);
router.post("/faculty", DataController.addFaculty);
router.post("/classrooms", DataController.addClassroom);
router.post("/timetables", DataController.addTimetable);
router.put("/timetables/:id", DataController.updateTimetable);

module.exports = router;