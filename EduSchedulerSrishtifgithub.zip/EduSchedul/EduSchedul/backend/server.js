const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3001;
const DB_PATH = path.join(__dirname, "db.json");

app.use(cors());
app.use(bodyParser.json());

// Read data from the mock database
const readDB = () => {
  try {
    const data = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return {
      subjects: [],
      faculty: [],
      classrooms: [],
      timetables: [],
      users: {},
    };
  }
};

// Write data to the mock database
const writeDB = (data) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf8");
};

// API Endpoints
app.get("/api/data", (req, res) => {
  const db = readDB();
  res.json({
    subjects: db.subjects,
    faculty: db.faculty,
    classrooms: db.classrooms,
    timetables: db.timetables,
  });
});

app.post("/api/subjects", (req, res) => {
  const db = readDB();
  const newSubject = { id: Date.now(), ...req.body };
  db.subjects.push(newSubject);
  writeDB(db);
  res.status(201).json(newSubject);
});

app.post("/api/faculty", (req, res) => {
  const db = readDB();
  const newFaculty = { id: Date.now(), ...req.body };
  db.faculty.push(newFaculty);
  writeDB(db);
  res.status(201).json(newFaculty);
});

app.post("/api/classrooms", (req, res) => {
  const db = readDB();
  const newClassroom = { id: Date.now(), ...req.body };
  db.classrooms.push(newClassroom);
  writeDB(db);
  res.status(201).json(newClassroom);
});

app.post("/api/timetables", (req, res) => {
  const db = readDB();
  const newTimetable = { id: Date.now(), status: "pending", ...req.body };
  db.timetables.push(newTimetable);
  writeDB(db);
  res.status(201).json(newTimetable);
});

app.put("/api/timetables/:id", (req, res) => {
  const db = readDB();
  const timetable = db.timetables.find((t) => t.id === parseInt(req.params.id));
  if (timetable) {
    timetable.status = req.body.status;
    writeDB(db);
    res.json(timetable);
  } else {
    res.status(404).send("Timetable not found");
  }
});

app.post("/api/register", (req, res) => {
  const db = readDB();
  const { username, password, role, email, fullName } = req.body;
  
  // Check if user already exists
  if (db.users[username]) {
    return res.status(400).json({ 
      success: false, 
      message: "Username already exists" 
    });
  }
  
  // Check if email already exists
  const existingUser = Object.values(db.users).find(user => user.email === email);
  if (existingUser) {
    return res.status(400).json({ 
      success: false, 
      message: "Email already exists" 
    });
  }
  
  // Add new user
  db.users[username] = {
    password,
    role,
    email,
    fullName,
    createdAt: new Date().toISOString()
  };
  
  writeDB(db);
  
  res.json({ 
    success: true, 
    message: "Registration successful",
    user: { username, role, email, fullName }
  });
});

app.post("/api/login", (req, res) => {
  const db = readDB();
  const { username, password, role } = req.body;
  if (db.users[username] && db.users[username].password === password) {
    res.json({ success: true, message: "Login successful", user: { username, role } });
  } else {
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
