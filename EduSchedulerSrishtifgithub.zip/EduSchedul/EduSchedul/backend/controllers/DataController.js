const { readDB, writeDB } = require('../models/database');

class DataController {
  // Get all data
  static getData(req, res) {
    const db = readDB();
    res.json({
      subjects: db.subjects,
      faculty: db.faculty,
      classrooms: db.classrooms,
      timetables: db.timetables,
    });
  }

  // Add subject
  static addSubject(req, res) {
    const db = readDB();
    const newSubject = { id: Date.now(), ...req.body };
    db.subjects.push(newSubject);
    writeDB(db);
    res.status(201).json(newSubject);
  }

  // Add faculty
  static addFaculty(req, res) {
    const db = readDB();
    const newFaculty = { id: Date.now(), ...req.body };
    db.faculty.push(newFaculty);
    writeDB(db);
    res.status(201).json(newFaculty);
  }

  // Add classroom
  static addClassroom(req, res) {
    const db = readDB();
    const newClassroom = { id: Date.now(), ...req.body };
    db.classrooms.push(newClassroom);
    writeDB(db);
    res.status(201).json(newClassroom);
  }

  // Add timetable
  static addTimetable(req, res) {
    const db = readDB();
    const newTimetable = { id: Date.now(), status: "pending", ...req.body };
    db.timetables.push(newTimetable);
    writeDB(db);
    res.status(201).json(newTimetable);
  }

  // Update timetable
  static updateTimetable(req, res) {
    const db = readDB();
    const timetable = db.timetables.find((t) => t.id === parseInt(req.params.id));
    if (timetable) {
      timetable.status = req.body.status;
      writeDB(db);
      res.json(timetable);
    } else {
      res.status(404).send("Timetable not found");
    }
  }
}

module.exports = DataController;