const { readDB, writeDB } = require('../models/database');

class AuthController {
  // Login user
  static login(req, res) {
    const db = readDB();
    const { username, password, role } = req.body;
    
    if (db.users[username] && db.users[username].password === password) {
      res.json({ 
        success: true, 
        message: "Login successful", 
        user: { username, role } 
      });
    } else {
      res.status(401).json({ 
        success: false, 
        message: "Invalid credentials" 
      });
    }
  }

  // Register new user
  static register(req, res) {
    const db = readDB();
    const { username, password, role, email, fullName } = req.body;
    
    // Check if user already exists
    if (db.users[username]) {
      return res.status(400).json({ 
        success: false, 
        message: "Username already exists" 
      });
    }
    
    // Check if email already exists
    const existingUser = Object.values(db.users).find(user => user.email === email);
    if (existingUser) {
      return res.status(400).json({ 
        success: false, 
        message: "Email already exists" 
      });
    }
    
    // Add new user
    db.users[username] = {
      password,
      role,
      email,
      fullName,
      createdAt: new Date().toISOString()
    };
    
    writeDB(db);
    
    res.json({ 
      success: true, 
      message: "Registration successful",
      user: { username, role, email, fullName }
    });
  }
}

module.exports = AuthController;